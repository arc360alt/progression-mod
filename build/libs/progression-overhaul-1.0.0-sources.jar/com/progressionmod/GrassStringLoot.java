package com.progressionmod;

import com.progressionmod.items.ModItems;
import net.fabricmc.fabric.api.loot.v2.LootTableEvents;
import net.minecraft.class_141;
import net.minecraft.class_1802;
import net.minecraft.class_2073;
import net.minecraft.class_219;
import net.minecraft.class_223;
import net.minecraft.class_2246;
import net.minecraft.class_2960;
import net.minecraft.class_44;
import net.minecraft.class_55;
import net.minecraft.class_5662;
import net.minecraft.class_77;

public class GrassStringLoot {
    public static void register() {
        LootTableEvents.MODIFY.register((resourceManager, lootManager, id, tableBuilder, source) -> {
            if (id.equals(class_2246.field_10479.method_26162())
             || id.equals(new class_2960("minecraft", "blocks/tall_grass"))) {

                // String drop — only with flint sword
                class_55.class_56 stringPool = class_55.method_347()
                    .method_352(class_44.method_32448(1))
                    .method_356(class_219.method_932(0.25f))
                    .method_356(class_223.method_945(
                        class_2073.class_2074.method_8973()
                            .method_8977(ModItems.FLINT_SWORD)
                    ))
                    .method_351(class_77.method_411(class_1802.field_8276))
                    .method_353(class_141.method_621(
                        class_5662.method_32462(1, 2)));

                tableBuilder.method_336(stringPool);
            }
        });
    }
}