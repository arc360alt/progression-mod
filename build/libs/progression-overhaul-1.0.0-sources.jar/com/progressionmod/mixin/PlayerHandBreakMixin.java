package com.progressionmod.mixin;

import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1831;
import net.minecraft.class_2680;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * Prevents players from breaking wood-type blocks with their bare hands.
 * Wood requires at least a Flint Axe.
 */
@Mixin(class_1657.class)
public class PlayerHandBreakMixin {

    @Inject(method = "getBlockBreakingSpeed", at = @At("RETURN"), cancellable = true)
    private void onGetBreakingSpeed(class_2680 state, CallbackInfoReturnable<Float> cir) {
        class_1657 player = (class_1657) (Object) this;
        class_1799 held = player.method_6047();

        boolean isUsingHand = !(held.method_7909() instanceof class_1831);

        if (isUsingHand) {
            if (state.method_27852(net.minecraft.class_2246.field_10431)
            || state.method_27852(net.minecraft.class_2246.field_10511)
            || state.method_27852(net.minecraft.class_2246.field_10037)
            || state.method_27852(net.minecraft.class_2246.field_10306)
            || state.method_27852(net.minecraft.class_2246.field_10533)
            || state.method_27852(net.minecraft.class_2246.field_10010)
            || state.method_27852(net.minecraft.class_2246.field_37545)
            || state.method_27852(net.minecraft.class_2246.field_42729)
            || state.method_27852(net.minecraft.class_2246.field_41072)
            || state.method_27852(net.minecraft.class_2246.field_10126)
            || state.method_27852(net.minecraft.class_2246.field_10307)
            || state.method_27852(net.minecraft.class_2246.field_10155)
            || state.method_27852(net.minecraft.class_2246.field_10303)
            || state.method_27852(net.minecraft.class_2246.field_9999)
            || state.method_27852(net.minecraft.class_2246.field_10178)
            || state.method_27852(net.minecraft.class_2246.field_37549)
            || state.method_27852(net.minecraft.class_2246.field_42733)) {
                cir.setReturnValue(0.001f);
            }
        }
    }
}
