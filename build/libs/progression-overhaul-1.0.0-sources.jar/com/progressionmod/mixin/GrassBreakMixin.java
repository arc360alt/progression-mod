package com.progressionmod.mixin;

import com.progressionmod.items.ModItems;
import net.minecraft.class_1799;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_3222;
import net.minecraft.class_3225;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_3225.class)
public class GrassBreakMixin {

    @Shadow
    protected class_3222 player;

    @Inject(method = "tryBreakBlock", at = @At("HEAD"))
    private void onTryBreakBlock(class_2338 pos, CallbackInfoReturnable<Boolean> cir) {
        class_2680 state = player.method_37908().method_8320(pos);

        if (state.method_27852(class_2246.field_10479) || state.method_27852(class_2246.field_10214)) {
            class_1799 held = player.method_6047();
            if (held.method_7909() == ModItems.FLINT_SWORD) {
                held.method_7956(1, player, p -> p.method_20236(player.method_6058()));
            }
        }
    }
}