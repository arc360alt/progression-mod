package com.progressionmod.mixin;

import com.progressionmod.items.ModItems;
import net.minecraft.class_1792;
import net.minecraft.class_1802;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_3222;
import net.minecraft.class_3225;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_3225.class)
public class MiningDropMixin {

    @Shadow
    protected class_3222 player;

    @Inject(method = "tryBreakBlock", at = @At("HEAD"), cancellable = true)
    private void preventWrongTierMining(class_2338 pos, CallbackInfoReturnable<Boolean> cir) {
        class_2680 state = player.method_37908().method_8320(pos);
        class_1792 held = player.method_6047().method_7909();
        int tier = getToolTier(held);

        if (tier < 0) return;

        if (isIronBlock(state) && tier < 4) { cir.setReturnValue(false); return; }
        if (isGoldBlock(state) && tier < 5) { cir.setReturnValue(false); return; }
        if (isDiamondOrDeepslateBlock(state) && tier < 6) { cir.setReturnValue(false); return; }
        if (isCopperBlock(state) && tier < 3) { cir.setReturnValue(false); return; }
    }

    private int getToolTier(class_1792 item) {
        if (item == ModItems.FLINT_PICKAXE || item == ModItems.FLINT_AXE
                || item == ModItems.FLINT_SHOVEL) return 1;
        if (item == class_1802.field_8647 || item == class_1802.field_8406
                || item == class_1802.field_8876) return 2;
        if (item == class_1802.field_8387 || item == class_1802.field_8062
                || item == class_1802.field_8776) return 3;
        if (item == ModItems.COPPER_PICKAXE || item == ModItems.COPPER_AXE
                || item == ModItems.COPPER_SHOVEL) return 4;
        if (item == class_1802.field_8403 || item == class_1802.field_8475
                || item == class_1802.field_8699) return 5;
        if (item == class_1802.field_8335 || item == class_1802.field_8825
                || item == class_1802.field_8322) return 6;
        if (item == class_1802.field_8377 || item == class_1802.field_8556
                || item == class_1802.field_8250) return 7;
        if (item == class_1802.field_22024 || item == class_1802.field_22025
                || item == class_1802.field_22023) return 8;
        return -1;
    }

    private boolean isCopperBlock(class_2680 state) {
        return state.method_27852(class_2246.field_27120) || state.method_27852(class_2246.field_33509);
    }

    private boolean isIronBlock(class_2680 state) {
        return state.method_27852(class_2246.field_10212) || state.method_27852(class_2246.field_33508)
            || state.method_27852(class_2246.field_10090) || state.method_27852(class_2246.field_10441);
    }

    private boolean isGoldBlock(class_2680 state) {
        return state.method_27852(class_2246.field_10571) || state.method_27852(class_2246.field_33510)
            || state.method_27852(class_2246.field_10080) || state.method_27852(class_2246.field_10013);
    }

    private boolean isDiamondOrDeepslateBlock(class_2680 state) {
        return state.method_27852(class_2246.field_10442)
            || state.method_27852(class_2246.field_29029)
            || state.method_27852(class_2246.field_29027)
            || state.method_27852(class_2246.field_29026)
            || state.method_27852(class_2246.field_29221)
            || state.method_27852(class_2246.field_29219)
            || state.method_27852(class_2246.field_29028)
            || state.method_27852(class_2246.field_29030)
            || state.method_27852(class_2246.field_29220)
            || state.method_27852(class_2246.field_22109);
    }
}