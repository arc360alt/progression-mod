package com.progressionmod.mixin;

import com.progressionmod.items.ModItems;
import net.minecraft.class_124;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2246;
import net.minecraft.class_2561;
import net.minecraft.class_2680;
import net.minecraft.class_3481;
import net.minecraft.item.*;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import com.progressionmod.ModConfig;

/**
 * Enforces the custom tier progression:
 *
 *  Flint     → can mine wood + dirt/gravel/sand (NOT stone)
 *  Wood      → can mine stone (NOT iron ore)
 *  Stone     → can mine copper ore (NOT iron ore)
 *  Copper    → can mine iron ore (NOT gold/diamond)
 *  Iron      → can mine gold ore (NOT diamond)
 *  Gold      → NOT useful for mining (low durability, can mine same as iron)
 *  Diamond   → can mine deepslate ores, ancient debris, etc.
 *
 * This mixin intercepts the effective tool check and overrides it.
 */
@Mixin(class_1657.class)
public class MiningLevelMixin {

    @Inject(method = "getBlockBreakingSpeed", at = @At("RETURN"), cancellable = true)
    private void enforceTierProgression(class_2680 state, CallbackInfoReturnable<Float> cir) {
        class_1657 player = (class_1657) (Object) this;
        class_1799 held = player.method_6047();
        class_1792 heldItem = held.method_7909();

        // ── Determine the "tier" of the held tool ────────────────────────────
        int toolTier = getToolTier(heldItem);
        if (toolTier < 0) return; // Not a tool we're tracking — let vanilla handle it

        // ── Check what block is being targeted ───────────────────────────────

        // STONE TIER blocks (require wood tools minimum)
        if (isStoneBlock(state)) {
            if (toolTier < 2) { // Less than wood (2)
            cir.setReturnValue(0.001f);
            if (ModConfig.get().showMiningTierMessages) {
                sendTierMessage(player, "You need at least a Wooden Pickaxe to mine stone!");
            }
            }
            return;
        }

        // COPPER ORE (requires stone tools minimum)
        if (isCopperBlock(state)) {
            if (toolTier < 3) {
                cir.setReturnValue(0.001f);
                if (ModConfig.get().showMiningTierMessages)
                    sendTierMessage(player, "You need at least a Stone Pickaxe to mine copper!");
            }
            return;
        }

        // IRON ORE (requires copper tools — tier 4)
        if (isIronBlock(state)) {
            if (toolTier < 4) {
                cir.setReturnValue(0.001f);
                if (ModConfig.get().showMiningTierMessages)
                    sendTierMessage(player, "You need at least a Copper Pickaxe to mine iron!");
            }
            return;
        }

        // GOLD ORE (requires iron tools — tier 5)
        if (isGoldBlock(state)) {
            if (toolTier < 5) {
                cir.setReturnValue(0.001f);
                if (ModConfig.get().showMiningTierMessages)
                    sendTierMessage(player, "You need at least an Iron Pickaxe to mine gold!");
            }
            return;
        }

        // DIAMOND/DEEPSLATE (requires gold tools — tier 6)
        if (isDiamondOrDeepslateBlock(state)) {
            if (toolTier < 6) {
                cir.setReturnValue(0.001f);
                if (ModConfig.get().showMiningTierMessages)
                    sendTierMessage(player, "You need at least a Gold Pickaxe to mine diamond/deepslate!");
            }
            return;
        }
    }

    // ── Tool Tier Mapping ─────────────────────────────────────────────────────
    // Returns -1 if not a recognised pickaxe-type tool
    private int getToolTier(class_1792 item) {
        // Flint = tier 1
        if (item == ModItems.FLINT_PICKAXE || item == ModItems.FLINT_AXE
                || item == ModItems.FLINT_SHOVEL || item == ModItems.FLINT_HOE) return 1;

        // Wood = tier 2
        if (item == class_1802.field_8647 || item == class_1802.field_8406
                || item == class_1802.field_8876) return 2;

        // Stone = tier 3
        if (item == class_1802.field_8387 || item == class_1802.field_8062
                || item == class_1802.field_8776) return 3;

        // Copper = tier 4
        if (item == ModItems.COPPER_PICKAXE || item == ModItems.COPPER_AXE
                || item == ModItems.COPPER_SHOVEL || item == ModItems.COPPER_HOE) return 4;

        // Iron = tier 5
        if (item == class_1802.field_8403 || item == class_1802.field_8475
                || item == class_1802.field_8699) return 5;

        // Gold = tier 6 (above iron — can mine diamond-tier blocks)
        if (item == class_1802.field_8335 || item == class_1802.field_8825
                || item == class_1802.field_8322) return 6;

        // Diamond = tier 7
        if (item == class_1802.field_8377 || item == class_1802.field_8556
                || item == class_1802.field_8250) return 7;

        // Netherite = tier 8
        if (item == class_1802.field_22024 || item == class_1802.field_22025
                || item == class_1802.field_22023) return 8;

        return -1; // Not a tool we track
    }

    // ── Block Category Checks ─────────────────────────────────────────────────

        private boolean isStoneBlock(class_2680 state) {
            return state.method_26164(class_3481.field_33715)
                    && !isCopperBlock(state)
                    && !isIronBlock(state)
                    && !isGoldBlock(state)
                    && !isDiamondOrDeepslateBlock(state)
                    && !isObsidianBlock(state);
        }

        // Requires stone tools (tier 3)
        private boolean isCopperBlock(class_2680 state) {
            return state.method_27852(class_2246.field_27120)
                || state.method_27852(class_2246.field_33509);
        }

        // Requires copper tools (tier 4)
        private boolean isIronBlock(class_2680 state) {
            return state.method_27852(class_2246.field_10212)
                || state.method_27852(class_2246.field_33508)
                || state.method_27852(class_2246.field_10090)
                || state.method_27852(class_2246.field_10441);
        }

        // Requires iron tools (tier 5)
        private boolean isGoldBlock(class_2680 state) {
            return state.method_27852(class_2246.field_10571)
                || state.method_27852(class_2246.field_33510)
                || state.method_27852(class_2246.field_10080)
                || state.method_27852(class_2246.field_10013);
        }

        // Requires gold tools (tier 6)
        private boolean isDiamondOrDeepslateBlock(class_2680 state) {
            return state.method_27852(class_2246.field_10442)
                || state.method_27852(class_2246.field_29029)
                || state.method_27852(class_2246.field_29027)
                || state.method_27852(class_2246.field_29026)
                || state.method_27852(class_2246.field_29221)
                || state.method_27852(class_2246.field_29219)
                || state.method_27852(class_2246.field_29028)
                || state.method_27852(class_2246.field_29030)
                || state.method_27852(class_2246.field_29220)
                || state.method_27852(class_2246.field_22109);
        }

        private boolean isObsidianBlock(class_2680 state) {
            return state.method_27852(class_2246.field_10540)
                || state.method_27852(class_2246.field_22423);
        }
    

    // ── Helper ────────────────────────────────────────────────────────────────
    private long lastMessageTime = 0;

    private void sendTierMessage(class_1657 player, String message) {
        // Throttle messages to avoid spamming every tick
        long now = player.method_37908().method_8510();
        if (now - lastMessageTime > 40) { // 2 seconds
            player.method_7353(class_2561.method_43470("⛏ " + message).method_27692(class_124.field_1061), true); // true = action bar
            lastMessageTime = now;
        }
    }
}
