package com.progressionmod.mixin;

import com.progressionmod.RecipeUnlocker;
import net.minecraft.class_1542;
import net.minecraft.class_1657;
import net.minecraft.class_3222;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_1542.class)
public class ItemPickupMixin {

    @Inject(method = "onPlayerCollision", at = @At("HEAD"))
    private void onPickup(class_1657 player, CallbackInfo ci) {
        if (player instanceof class_3222 serverPlayer) {
            class_1542 itemEntity = (class_1542)(Object)this;
            RecipeUnlocker.tryUnlock(serverPlayer, itemEntity.method_6983().method_7909());
        }
    }
}