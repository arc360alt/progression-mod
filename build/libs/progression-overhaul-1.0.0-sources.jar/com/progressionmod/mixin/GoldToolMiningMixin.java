package com.progressionmod.mixin;

import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2680;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_1799.class)
public class GoldToolMiningMixin {

    @Inject(method = "isSuitableFor", at = @At("RETURN"), cancellable = true)
    private void allowGoldToMineAnything(class_2680 state, CallbackInfoReturnable<Boolean> cir) {
        class_1799 self = (class_1799)(Object)this;
        class_1792 item = self.method_7909();

        boolean isGoldTool = item == class_1802.field_8335
                          || item == class_1802.field_8825
                          || item == class_1802.field_8322;

        if (isGoldTool) {
            cir.setReturnValue(true);
        }
    }
}