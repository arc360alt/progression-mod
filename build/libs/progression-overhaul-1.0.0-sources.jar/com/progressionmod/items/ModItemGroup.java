package com.progressionmod.items;

import com.progressionmod.ProgressionMod;
import net.fabricmc.fabric.api.itemgroup.v1.FabricItemGroup;
import net.minecraft.class_1761;
import net.minecraft.class_1799;
import net.minecraft.class_2378;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_7923;

public class ModItemGroup {
    public static final class_1761 PROGRESSION_GROUP = class_2378.method_10230(
        class_7923.field_44687,
        new class_2960(ProgressionMod.MOD_ID, "progression_tools"),
        FabricItemGroup.builder()
            .method_47321(class_2561.method_43470("Progression Overhaul"))
            .method_47320(() -> new class_1799(ModItems.FLINT_AXE))
            .method_47317((context, entries) -> {
                entries.method_45421(ModItems.FLINT_AXE);
                entries.method_45421(ModItems.FLINT_PICKAXE);
                entries.method_45421(ModItems.FLINT_SHOVEL);
                entries.method_45421(ModItems.FLINT_SWORD);
                entries.method_45421(ModItems.FLINT_HOE);
                entries.method_45421(ModItems.COPPER_AXE);
                entries.method_45421(ModItems.COPPER_PICKAXE);
                entries.method_45421(ModItems.COPPER_SHOVEL);
                entries.method_45421(ModItems.COPPER_SWORD);
                entries.method_45421(ModItems.COPPER_HOE);
                entries.method_45421(ModItems.COPPER_HELMET);
                entries.method_45421(ModItems.COPPER_CHESTPLATE);
                entries.method_45421(ModItems.COPPER_LEGGINGS);
                entries.method_45421(ModItems.COPPER_BOOTS);
            })
            .method_47324()
    );

    public static void registerItemGroup() {
        ProgressionMod.LOGGER.info("Registering Item Groups...");
    }
}