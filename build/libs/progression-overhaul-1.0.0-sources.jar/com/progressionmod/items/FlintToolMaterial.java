package com.progressionmod.items;

import net.minecraft.class_1832;
import net.minecraft.class_1856;

public enum FlintToolMaterial implements class_1832 {
    INSTANCE;

    private static final int MINING_LEVEL = 1; 
    private static final int ITEM_DURABILITY = 45; 
    private static final float MINING_SPEED = 1.1f; 
    private static final float ATTACK_DAMAGE = 0.5f; 
    private static final int ENCHANTABILITY = 5; 

    @Override
    public int method_8025() {
        return ITEM_DURABILITY;
    }

    @Override
    public float method_8027() {
        return MINING_SPEED;
    }

    @Override
    public float method_8028() {
        return ATTACK_DAMAGE;
    }

    @Override
    public int method_8024() {
        return MINING_LEVEL;
    }

    @Override
    public int method_8026() {
        return ENCHANTABILITY;
    }

    @Override
    public class_1856 method_8023() {
        return class_1856.method_8091(net.minecraft.class_1802.field_8145);
    }
}
