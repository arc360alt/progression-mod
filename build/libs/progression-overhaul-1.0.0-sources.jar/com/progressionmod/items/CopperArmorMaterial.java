package com.progressionmod.items;

import net.minecraft.class_1738;
import net.minecraft.class_1741;
import net.minecraft.class_1856;
import net.minecraft.class_3414;
import net.minecraft.class_3417;

public enum CopperArmorMaterial implements class_1741 {
    INSTANCE;

    // Protection values: Iron is 2/5/6/2, we do slightly less
    private static final int[] PROTECTION = {1, 4, 5, 2}; // feet, legs, chest, head
    private static final int DURABILITY_BASE = 160; // Iron=165, ours is just under
    private static final int[] DURABILITY_MULTIPLIERS = {13, 15, 16, 11};

    @Override
    public int method_48402(class_1738.class_8051 type) {
        return DURABILITY_MULTIPLIERS[type.ordinal()] * DURABILITY_BASE / 100;
    }

    @Override
    public int method_48403(class_1738.class_8051 type) {
        return PROTECTION[type.ordinal()];
    }

    @Override
    public int method_7699() { return 8; }

    @Override
    public class_3414 method_7698() { return class_3417.field_14862; }

    @Override
    public class_1856 method_7695() {
        return class_1856.method_8091(net.minecraft.class_1802.field_27022);
    }

    @Override
    public String method_7694() { return "progressionmod:copper"; }

    @Override
    public float method_7700() { return 0.0f; }

    @Override
    public float method_24355() { return 0.0f; }
}