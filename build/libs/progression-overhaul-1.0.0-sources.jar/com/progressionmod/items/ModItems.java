package com.progressionmod.items;

import com.progressionmod.ProgressionMod;
import net.fabricmc.fabric.api.item.v1.FabricItemSettings;
import net.minecraft.class_1738;
import net.minecraft.class_1743;
import net.minecraft.class_1792;
import net.minecraft.class_1794;
import net.minecraft.class_1810;
import net.minecraft.class_1821;
import net.minecraft.class_1829;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_7923;
import net.minecraft.item.*;

public class ModItems {

    // ── Flint Tools ──────────────────────────────────────────────────────────
    public static final class_1792 FLINT_AXE = register("flint_axe",
            new class_1743(FlintToolMaterial.INSTANCE, 5.0f, -3.1f, new FabricItemSettings()));

    public static final class_1792 FLINT_PICKAXE = register("flint_pickaxe",
            new class_1810(FlintToolMaterial.INSTANCE, 1, -2.8f, new FabricItemSettings()));

    public static final class_1792 FLINT_SHOVEL = register("flint_shovel",
            new class_1821(FlintToolMaterial.INSTANCE, 1.5f, -3.0f, new FabricItemSettings()));

    public static final class_1792 FLINT_HOE = register("flint_hoe",
            new class_1794(FlintToolMaterial.INSTANCE, -1, -2.0f, new FabricItemSettings()));

    public static final class_1792 FLINT_SWORD = register("flint_sword",
            new class_1829(FlintToolMaterial.INSTANCE, 3, -2.4f, new FabricItemSettings()));

    // ── Copper Tools ─────────────────────────────────────────────────────────
    public static final class_1792 COPPER_AXE = register("copper_axe",
            new class_1743(CopperToolMaterial.INSTANCE, 6.0f, -3.1f, new FabricItemSettings()));

    public static final class_1792 COPPER_PICKAXE = register("copper_pickaxe",
            new class_1810(CopperToolMaterial.INSTANCE, 1, -2.8f, new FabricItemSettings()));

    public static final class_1792 COPPER_SHOVEL = register("copper_shovel",
            new class_1821(CopperToolMaterial.INSTANCE, 1.5f, -3.0f, new FabricItemSettings()));

    public static final class_1792 COPPER_HOE = register("copper_hoe",
            new class_1794(CopperToolMaterial.INSTANCE, -2, -1.0f, new FabricItemSettings()));

    public static final class_1792 COPPER_SWORD = register("copper_sword",
            new class_1829(CopperToolMaterial.INSTANCE, 3, -2.4f, new FabricItemSettings()));

        // ── Copper Armor ─────────────────────────────────────────────────────────
        public static final class_1792 COPPER_HELMET = register("copper_helmet",
                new class_1738(CopperArmorMaterial.INSTANCE, class_1738.class_8051.field_41934, new FabricItemSettings()));

        public static final class_1792 COPPER_CHESTPLATE = register("copper_chestplate",
                new class_1738(CopperArmorMaterial.INSTANCE, class_1738.class_8051.field_41935, new FabricItemSettings()));

        public static final class_1792 COPPER_LEGGINGS = register("copper_leggings",
                new class_1738(CopperArmorMaterial.INSTANCE, class_1738.class_8051.field_41936, new FabricItemSettings()));

        public static final class_1792 COPPER_BOOTS = register("copper_boots",
                new class_1738(CopperArmorMaterial.INSTANCE, class_1738.class_8051.field_41937, new FabricItemSettings()));

    // ── Helper ───────────────────────────────────────────────────────────────
    private static class_1792 register(String name, class_1792 item) {
        return class_2378.method_10230(class_7923.field_41178, new class_2960(ProgressionMod.MOD_ID, name), item);
    }

    public static void registerItems() {
        ProgressionMod.LOGGER.info("Registering Flint & Copper Tools...");
    }
}
