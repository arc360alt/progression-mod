package com.progressionmod;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import net.minecraft.class_1792;
import net.minecraft.class_1802;
import net.minecraft.class_2960;
import net.minecraft.class_3222;

public class RecipeUnlocker {

    public static final Map<class_1792, List<String>> UNLOCK_MAP = new HashMap<>();

    static {
        List<String> allFlintRecipes = List.of(
                "progressionmod:flint_axe",
                "progressionmod:flint_pickaxe",
                "progressionmod:flint_shovel",
                "progressionmod:flint_sword",
                "progressionmod:flint_hoe"
        );

        List<String> allCopperRecipes = List.of(
                "progressionmod:copper_axe",
                "progressionmod:copper_pickaxe",
                "progressionmod:copper_shovel",
                "progressionmod:copper_sword",
                "progressionmod:copper_hoe",
                "progressionmod:copper_helmet",
                "progressionmod:copper_chestplate",
                "progressionmod:copper_leggings",
                "progressionmod:copper_boots"
        );

        UNLOCK_MAP.put(class_1802.field_8145, allFlintRecipes);
        UNLOCK_MAP.put(class_1802.field_27022, allCopperRecipes);

        UNLOCK_MAP.put(class_1802.field_8110, List.of("progressionmod:sticks_from_gravel"));
        UNLOCK_MAP.put(class_1802.field_17503, List.of("progressionmod:sticks_from_leaves"));
    }

    public static void tryUnlock(class_3222 player, class_1792 pickedUp) {
        List<String> toUnlock = UNLOCK_MAP.get(pickedUp);
        if (toUnlock == null) return;

        class_2960[] ids = toUnlock.stream()
                .map(id -> new class_2960(id))
                .toArray(class_2960[]::new);

        player.method_7335(ids);
    }

    public static void register() {
        // Registration is handled via the ItemPickupMixin
    }
}